import React from 'react';

interface SectionProps {
  title: string;
  children: React.ReactNode;
  className?: string;
  id?: string;
}

const Section: React.FC<SectionProps> = ({ title, children, className = '', id }) => {
  return (
    <section id={id} className={`mb-20 animate-slide-up section-3d ${className}`}>
      <div className="relative mb-12 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-slate-100 mb-4 text-3d">
          {title}
        </h2>
        <div className="flex justify-center">
          <div className="h-1 w-24 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"></div>
        </div>
        <div className="flex justify-center mt-2">
          <div className="h-1 w-16 bg-gradient-to-r from-purple-600 to-pink-500 rounded-full opacity-60"></div>
        </div>
      </div>
      {children}
    </section>
  );
};

export default Section;
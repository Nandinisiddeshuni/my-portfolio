import React from 'react';
import { Mail, Phone, Linkedin, Github, Award, Download } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header id="about" className="relative min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white flex items-center justify-center overflow-hidden">
      {/* Enhanced animated background particles */}
      <div className="particles absolute inset-0">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="particle floating-3d"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${Math.random() * 6 + 3}px`,
              height: `${Math.random() * 6 + 3}px`,
              animationDelay: `${Math.random() * 8}s`,
              animationDuration: `${Math.random() * 4 + 6}s`
            }}
          />
        ))}
      </div>
      
      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 relative z-10 text-center">
        {/* Large Heading at Top */}
        <div className="mb-16">
          <h1 className="text-6xl md:text-8xl font-black mb-6 bg-gradient-to-r from-blue-400 via-purple-400 to-blue-300 bg-clip-text text-transparent text-3d animate-fade-in">
            Siddeshuni Nandini
          </h1>
          <h2 className="text-5xl font-extrabold text-gradient bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-transparent bg-clip-text text-center my-8 shadow-md drop-shadow-lg">
            Siddeshuni Nandini
          </h2>
        </div>

        {/* Centered Profile Picture */}
        <div className="flex justify-center mb-12">
          <div className="relative group profile-3d">
            <div className="absolute -inset-2 bg-gradient-to-r from-blue-500 via-purple-600 to-pink-500 rounded-full blur-lg opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 glow-animation"></div>
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full blur opacity-90 group-hover:opacity-100 transition duration-1000"></div>
            <img 
              src="/images/profile.jpg" 
              alt="Siddeshuni Nandini" 
              className="relative w-48 h-48 md:w-64 md:h-64 rounded-full border-4 border-slate-700 shadow-2xl object-cover transform transition-all duration-500 hover:scale-105"
            />
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          </div>
        </div>

        {/* Subtitle and Description */}
        <div className="mb-12">
          <p className="text-2xl md:text-3xl mb-6 text-slate-300 font-light">
            Computer Science Engineering Student & Aspiring Full Stack Developer
          </p>
          <p className="text-lg md:text-xl text-slate-400 max-w-3xl mx-auto leading-relaxed">
            Passionate about Machine Learning and Full Stack Development with expertise in building innovative solutions that bridge technology and real-world applications
          </p>
        </div>
        
        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center mb-16">
          <a 
            href="mailto:nandinisiddeshunin123@gmail.com"
            className="button-3d inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-semibold text-lg shadow-lg hover:shadow-2xl transition-all duration-300"
          >
            <Mail size={20} />
            Contact Me
          </a>
          <button className="button-3d inline-flex items-center gap-3 px-8 py-4 bg-slate-800/80 text-slate-200 rounded-xl font-semibold text-lg border border-slate-600 hover:border-blue-500/50 transition-all duration-300">
            <Download size={20} />
            Download CV
          </button>
        </div>
        
        {/* Contact Links */}
        <div className="flex flex-wrap justify-center gap-4 text-sm">
          <a href="mailto:nandinisiddeshunin123@gmail.com" 
             className="button-3d flex items-center gap-2 px-6 py-3 glass-effect rounded-xl hover:bg-slate-700/50 transition-all duration-300 border border-slate-600/50 hover:border-blue-500/50">
            <Mail size={16} className="text-blue-400" />
            <span className="text-slate-200">nandinisiddeshunin123@gmail.com</span>
          </a>
          <a href="tel:+91-7386373055" 
             className="button-3d flex items-center gap-2 px-6 py-3 glass-effect rounded-xl hover:bg-slate-700/50 transition-all duration-300 border border-slate-600/50 hover:border-green-500/50">
            <Phone size={16} className="text-green-400" />
            <span className="text-slate-200">+91-7386373055</span>
          </a>
          <a href="https://www.linkedin.com/in/nandini-siddeshuni-ba3491283/" 
             target="_blank" rel="noopener noreferrer"
             className="button-3d flex items-center gap-2 px-6 py-3 glass-effect rounded-xl hover:bg-slate-700/50 transition-all duration-300 border border-slate-600/50 hover:border-blue-500/50">
            <Linkedin size={16} className="text-blue-500" />
            <span className="text-slate-200">LinkedIn</span>
          </a>
          <a href="https://github.com/Nandinisiddeshuni" 
             target="_blank" rel="noopener noreferrer"
             className="button-3d flex items-center gap-2 px-6 py-3 glass-effect rounded-xl hover:bg-slate-700/50 transition-all duration-300 border border-slate-600/50 hover:border-slate-400/50">
            <Github size={16} className="text-slate-300" />
            <span className="text-slate-200">GitHub</span>
          </a>
          <a href="https://www.credly.com/users/nandini-siddeshuni" 
             target="_blank" rel="noopener noreferrer"
             className="button-3d flex items-center gap-2 px-6 py-3 glass-effect rounded-xl hover:bg-slate-700/50 transition-all duration-300 border border-slate-600/50 hover:border-yellow-500/50">
            <Award size={16} className="text-yellow-400" />
            <span className="text-slate-200">Credly</span>
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
import React from 'react';
import { ExternalLink, Calendar } from 'lucide-react';

interface ExperienceCardProps {
  title: string;
  description: string[];
  githubUrl: string;
  date: string;
  logoUrl: string;
}

const ExperienceCard: React.FC<ExperienceCardProps> = ({ 
  title, 
  description, 
  githubUrl, 
  date, 
  logoUrl 
}) => {
  return (
    <div className="card-3d glass-effect rounded-2xl p-8 border border-slate-700/50 group overflow-hidden relative">
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 via-transparent to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      
      <div className="relative z-10">
        <div className="flex items-start gap-6">
          <div className="relative profile-3d">
            <img 
              src={logoUrl} 
              alt={`${title} logo`} 
              className="w-20 h-20 rounded-2xl object-cover border-2 border-slate-600 group-hover:border-green-500/50 transition-all duration-300 shadow-lg" 
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-green-500/20 to-blue-500/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-2xl font-bold text-slate-100 group-hover:text-green-300 transition-colors duration-300 text-3d">
                {title}
              </h3>
              <div className="flex items-center gap-2 text-slate-400 text-sm bg-slate-800/50 px-3 py-1 rounded-lg">
                <Calendar size={14} />
                <span>{date}</span>
              </div>
            </div>
            
            <ul className="space-y-4 mb-8">
              {description.map((item, index) => (
                <li key={index} className="text-slate-300 flex items-start leading-relaxed text-lg">
                  <span className="text-blue-400 mr-4 mt-1 text-xl">▸</span>
                  {item}
                </li>
              ))}
            </ul>
            
            <a 
              href={githubUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="button-3d inline-flex items-center gap-3 px-6 py-3 bg-slate-800/50 text-slate-200 rounded-xl hover:bg-slate-700/50 transition-all duration-300 border border-slate-600/50 hover:border-green-500/50 hover:text-green-300 font-medium"
            >
              <ExternalLink size={18} />
              View Project
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExperienceCard;
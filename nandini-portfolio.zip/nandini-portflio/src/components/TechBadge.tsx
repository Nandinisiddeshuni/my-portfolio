import React from 'react';

interface TechBadgeProps {
  name: string;
  color?: string;
}

const TechBadge: React.FC<TechBadgeProps> = ({ name, color = 'bg-blue-500/20 text-blue-300 border-blue-500/30' }) => {
  return (
    <span className={`tech-badge-3d inline-block px-4 py-2 rounded-xl text-sm font-semibold border ${color} mr-3 mb-3 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer`}>
      {name}
    </span>
  );
};

export default TechBadge;
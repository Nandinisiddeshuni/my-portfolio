import React from 'react';
import Navigation from './components/Navigation';
import Header from './components/Header';
import Section from './components/Section';
import TechBadge from './components/TechBadge';
import ProjectCard from './components/ProjectCard';
import ExperienceCard from './components/ExperienceCard';
import { GraduationCap, Award, User, Briefcase, Code, Trophy, Brain, Users } from 'lucide-react';

function App() {
  const projects = [
    {
      title: "Indian Language Community Chatbot",
      description: "Built a multilingual chatbot supporting Telugu, Hindi, Tamil, Malayalam, and English for community engagement using advanced NLP techniques and machine learning algorithms.",
      technologies: ["Python", "NLP", "Machine Learning", "Multi-language Processing", "TensorFlow"],
      githubUrl: "https://github.com/Nandinisiddeshuni/Indian-language-community-chatbot",
      date: "November 2024",
      logoUrl: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      title: "Timetable – 2nd Year Students",
      description: "Created a dynamic timetable system with intelligent conflict detection algorithms to automate scheduling for coordinators, reducing manual effort by 80%.",
      technologies: ["Web Development", "JavaScript", "Algorithm Design", "Scheduling", "React"],
      githubUrl: "https://github.com/Nandinisiddeshuni/Timetable-2rdyearStudents",
      date: "June 2024",
      logoUrl: "https://images.pexels.com/photos/273230/pexels-photo-273230.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      title: "Chess Dataset Analysis",
      description: "Analyzed 18,000+ chess games using advanced data science techniques with Pandas and Seaborn to uncover strategic trends in performance, openings, and player behaviors.",
      technologies: ["Python", "Pandas", "Seaborn", "Data Analysis", "Visualization", "Statistics"],
      githubUrl: "https://github.com/Nandinisiddeshuni/CHESS-Datasetsss",
      date: "September 2024",
      logoUrl: "https://images.pexels.com/photos/260024/pexels-photo-260024.jpeg?auto=compress&cs=tinysrgb&w=400"
    }
  ];

  const experience = [
    {
      title: "Crop Yield Prediction Research",
      description: [
        "Integrated over 10,000 records of climatic, soil, and crop data to enhance prediction accuracy using machine learning models.",
        "Boosted model accuracy by 15% and improved resource allocation efficiency by 10% through effective data preprocessing and feature engineering.",
        "Implemented ensemble methods and cross-validation techniques to ensure robust model performance."
      ],
      githubUrl: "https://github.com/Nandinisiddeshuni/Research-Paper",
      date: "July–Sep 2024",
      logoUrl: "https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg?auto=compress&cs=tinysrgb&w=400"
    }
  ];

  const certifications = [
    {
      name: "MongoDB Basics for Students",
      url: "https://drive.google.com/file/d/1Ys02ke94CR6wREoROBrb1NY9Gt54Y70l/view?usp=drive_link"
    },
    {
      name: "Walmart USA Advanced Software Engineering Virtual Experience Program",
      url: "https://colab.research.google.com/drive/1RXKa_XOsnSIJodPUgTFqdWo2b17oHesr?usp=sharing"
    },
    {
      name: "Junior Cybersecurity Analyst",
      url: "https://drive.google.com/file/d/1bynDAGeKsHLy8refrwKNq5QOwr8a4F5m/view?usp=drive_link"
    },
    {
      name: "Theory of Computation",
      url: "https://drive.google.com/file/d/1wAlAmMB-LG9P3drimoiUuMAnEkaEyaaZ/view?usp=drive_link"
    },
    {
      name: "Introduction to Web Development",
      url: "https://drive.google.com/file/d/1QOne2vax50NWDHa5JaL-ufERKDTBbGSW/view?usp=drive_link"
    },
    {
      name: "Networking Basics",
      url: "https://drive.google.com/file/d/19eJG7FvWKxDgraL6ZqhY4YjzVj9jfdrQ/view?usp=drive_link"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-900">
      <Navigation />
      <Header />
      
      <main className="max-w-7xl mx-auto px-6 py-20">
        <Section title="Education" id="education">
          <div className="card-3d glass-effect rounded-2xl p-10 border border-slate-700/50 max-w-4xl mx-auto">
            <div className="flex items-start gap-8">
              <div className="p-4 bg-blue-500/20 rounded-2xl border border-blue-500/30 profile-3d">
                <GraduationCap className="text-blue-400" size={32} />
              </div>
              <div className="flex-1">
                <h3 className="text-3xl font-bold text-slate-100 mb-4 text-3d">SR University</h3>
                <p className="text-xl text-slate-200 mb-4">Bachelor of Technology in Computer Science and Engineering</p>
                <p className="text-slate-400 mb-6 text-lg">November 2022 – April 2026</p>
                <div className="mb-8">
                  <span className="font-semibold text-slate-300 text-lg">GPA: </span>
                  <span className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">8.1/10.0</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-300 block mb-6 text-lg">Coursework:</span>
                  <div className="flex flex-wrap gap-3">
                    {["Web Development", "Machine Learning", "Data Structures", "Design and Analysis of Algorithms", "OOP", "OS", "Computer Networks", "Data Mining", "C", "Python"].map((course, index) => (
                      <TechBadge key={index} name={course} color="bg-green-500/20 text-green-300 border-green-500/30" />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Section>

        <Section title="Technical Skills">
          <div className="card-3d glass-effect rounded-2xl p-10 border border-slate-700/50">
            <div className="grid md:grid-cols-2 gap-10">
              <div>
                <h4 className="font-bold text-slate-200 mb-6 text-xl flex items-center gap-3">
                  <Code className="text-blue-400" size={24} />
                  Programming Languages
                </h4>
                <div className="flex flex-wrap gap-3 mb-8">
                  {["C", "Python", "Java"].map((lang, index) => (
                    <TechBadge key={index} name={lang} color="bg-blue-500/20 text-blue-300 border-blue-500/30" />
                  ))}
                </div>
                
                <h4 className="font-bold text-slate-200 mb-6 text-xl flex items-center gap-3">
                  <Code className="text-orange-400" size={24} />
                  Web Technologies
                </h4>
                <div className="flex flex-wrap gap-3 mb-8">
                  {["HTML", "CSS", "JavaScript", "React"].map((tech, index) => (
                    <TechBadge key={index} name={tech} color="bg-orange-500/20 text-orange-300 border-orange-500/30" />
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-bold text-slate-200 mb-6 text-xl flex items-center gap-3">
                  <Briefcase className="text-purple-400" size={24} />
                  Databases
                </h4>
                <div className="flex flex-wrap gap-3 mb-8">
                  {["SQL", "MySQL", "PLSQL", "MongoDB", "PostgreSQL"].map((db, index) => (
                    <TechBadge key={index} name={db} color="bg-purple-500/20 text-purple-300 border-purple-500/30" />
                  ))}
                </div>
                
                <h4 className="font-bold text-slate-200 mb-6 text-xl flex items-center gap-3">
                  <Brain className="text-red-400" size={24} />
                  Domain Expertise
                </h4>
                <div className="flex flex-wrap gap-3">
                  {["Machine Learning", "Full Stack Development", "Data Science"].map((domain, index) => (
                    <TechBadge key={index} name={domain} color="bg-red-500/20 text-red-300 border-red-500/30" />
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mt-10 pt-8 border-t border-slate-700/50">
              <h4 className="font-bold text-slate-200 mb-6 text-xl">Specialized Skills</h4>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="card-3d flex items-start gap-4 p-6 glass-effect-light rounded-xl border border-slate-700/30">
                  <span className="text-blue-400 text-2xl">📊</span>
                  <div>
                    <h5 className="font-semibold text-slate-200 mb-2 text-lg">Data Visualization</h5>
                    <p className="text-slate-400">Advanced proficiency with Pandas, Matplotlib, Seaborn for creating insightful data visualizations</p>
                  </div>
                </div>
                <div className="card-3d flex items-start gap-4 p-6 glass-effect-light rounded-xl border border-slate-700/30">
                  <span className="text-green-400 text-2xl">⚡</span>
                  <div>
                    <h5 className="font-semibold text-slate-200 mb-2 text-lg">Automation</h5>
                    <p className="text-slate-400">Workflow automation using Python scripting and process optimization</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Section>

        <Section title="Experience" id="experience">
          <div className="space-y-8">
            {experience.map((exp, index) => (
              <ExperienceCard key={index} {...exp} />
            ))}
          </div>
        </Section>

        <Section title="Projects" id="projects">
          <div className="grid gap-10">
            {projects.map((project, index) => (
              <ProjectCard key={index} {...project} />
            ))}
          </div>
        </Section>

        <Section title="Core Strengths">
          <div className="card-3d glass-effect rounded-2xl p-10 border border-slate-700/50">
            <div className="grid md:grid-cols-2 gap-10">
              <div className="card-3d flex items-start gap-6 p-8 glass-effect-light rounded-2xl border border-slate-700/30">
                <div className="p-4 bg-blue-500/20 rounded-2xl border border-blue-500/30 profile-3d">
                  <Brain className="text-blue-400" size={28} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-100 mb-4 text-xl">Analytical & Research-Focused</h4>
                  <p className="text-slate-300 leading-relaxed text-lg">Demonstrated expertise in solving complex real-world ML problems including spam classification, yield forecasting, and data-driven decision making.</p>
                </div>
              </div>
              <div className="card-3d flex items-start gap-6 p-8 glass-effect-light rounded-2xl border border-slate-700/30">
                <div className="p-4 bg-green-500/20 rounded-2xl border border-green-500/30 profile-3d">
                  <Users className="text-green-400" size={28} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-100 mb-4 text-xl">Collaborative Leadership</h4>
                  <p className="text-slate-300 leading-relaxed text-lg">Highly effective in team environments with strong communication skills and experience in technical presentations and project coordination.</p>
                </div>
              </div>
            </div>
          </div>
        </Section>

        <Section title="Certifications & Achievements" id="contact">
          <div className="card-3d glass-effect rounded-2xl p-10 border border-slate-700/50">
            <div className="grid gap-6">
              {certifications.map((cert, index) => (
                <div key={index} className="card-3d flex items-center justify-between p-6 glass-effect-light rounded-xl hover:bg-slate-700/30 transition-all duration-300 border border-slate-700/30 hover:border-blue-500/30 group">
                  <div className="flex items-center gap-6">
                    <div className="p-3 bg-yellow-500/20 rounded-xl border border-yellow-500/30 group-hover:bg-yellow-500/30 transition-colors duration-300 profile-3d">
                      <Award className="text-yellow-400" size={24} />
                    </div>
                    <span className="font-medium text-slate-200 group-hover:text-slate-100 transition-colors duration-300 text-lg">{cert.name}</span>
                  </div>
                  <a 
                    href={cert.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="button-3d px-6 py-3 bg-blue-500/20 text-blue-300 rounded-xl hover:bg-blue-500/30 transition-all duration-300 font-medium border border-blue-500/30 hover:border-blue-400/50"
                  >
                    Verify
                  </a>
                </div>
              ))}
            </div>
          </div>
        </Section>
      </main>
      
      <footer className="glass-effect border-t border-slate-700/50 text-slate-300 py-16 text-center">
        <div className="max-w-4xl mx-auto px-6">
          <p className="text-xl mb-3">&copy; 2024 Siddeshuni Nandini. All rights reserved.</p>
          <p className="text-slate-400 text-lg">Built with React, TypeScript, and Tailwind CSS</p>
        </div>
      </footer>
    </div>
  );
}

export default App;